class Student
{
    constructor(sno,sname)
    {
     this.sno=sno;
     this.sname=sname;
    }
    display()
    {
        console.log(`sno is ${this.sno} and name is ${this.sname}`)
    }
}

obj = new Student(1001,"manish")
obj.display()