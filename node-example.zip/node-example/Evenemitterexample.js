var events = require('events');
var eventemitter = new events.EventEmitter();
var fun=function()   //event method
{
    console.log('hello world');
}
eventemitter.on('myclick',fun);  //define the event
eventemitter.emit('myclick')  //execute the event