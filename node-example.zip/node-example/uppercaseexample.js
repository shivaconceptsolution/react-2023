var obj = require('upper-case')
console.log(obj.upperCase("welcome in scs"))