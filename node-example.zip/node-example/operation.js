
 exports.addition=function(a,b){
console.log(a+b)
}

exports.substraction=function(a,b){
    return a-b
    }

exports.multiplication=function(){
        var a=10;
        var b=2;
        return a*b
        }

exports.division=function(a,b){
         var a=10;
         var b=2;
         console.log(a/b)
}