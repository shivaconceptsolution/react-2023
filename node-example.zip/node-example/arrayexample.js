x = [12,23,67,78,89,11]
for(var value of x)
{
    console.log(value)
}
x.forEach((key) => {
    console.log(key);
});