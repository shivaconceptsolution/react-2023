var express = require('express'); 
var app = express()
app.get('/',function(req,res){
  res.send("Welcome in GET REQUEST")
})
app.get('/abc',function(req,res){
    res.send("Welcome in GET NAMED REQUEST")
  })
app.post('/stu',function(req,res){
    res.send("Welcome in POST REQUEST")
  })  
app.put('/stu',function(req,res){
    res.send("Welcome in PUT REQUEST")
  })  
app.delete('/stu',function(req,res){
    res.send("Welcome in delete REQUEST")
  })  

var server = app.listen(2000, function () {  
    var host = server.address().address;  
    var port = server.address().port;  
    console.log('Example app listening at http://%s:%s', host, port);  
  });  