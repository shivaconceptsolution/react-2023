const { error } = require('console')
var fs = require('fs')
fs.open('hello.txt','w',function(err,file){
    if(err)
    throw error
    console.log('file created')
})
fs.writeFile('hello.txt','welcome in file handlinhg',function(err){
    if(err)
    throw error
})
fs.readFile('hello.txt',function(err,data){
    if(err)
    throw error
    var d = data.toString()
    console.log(d)
})
fs.appendFile('hello.txt',' node js session',function(err){
    if(err)
    throw error
})

/*fs.unlink('hello.txt',function(err){
    if(err)
    throw error
})*/

fs.rename('hello.txt','hellonew.txt',function(err){
    if(err)
    throw error
})